/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef ANALYSIS-72_4_0_PRIVATE_H
#define ANALYSIS-72_4_0_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"4.0.2.26"
#define VER_MAJOR	4
#define VER_MINOR	0
#define VER_RELEASE	2
#define VER_BUILD	26
#define COMPANY_NAME	"SteelsOfLiquid - https://github.com/steelsofliquid"
#define FILE_VERSION	"4.0.2.26"
#define FILE_DESCRIPTION	"Analysis-72 4.0"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	""
#define PRODUCT_VERSION	"4.0.2.26"

#endif /*ANALYSIS-72_4_0_PRIVATE_H*/
